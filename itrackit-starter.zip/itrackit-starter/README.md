# ITrackit — Starter

Backend: Node/Express/Prisma
Frontend: React/Vite
DB: Postgres (Docker or hosted)
