import express from "express";
const app = express();
app.get("/", (_req,res)=>res.json({ok:true}))
app.listen(4000, ()=>console.log("API http://localhost:4000"))
